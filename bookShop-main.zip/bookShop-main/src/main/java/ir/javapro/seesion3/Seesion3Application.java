package ir.javapro.seesion3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Seesion3Application {

    public static void main(String[] args) {
        SpringApplication.run(Seesion3Application.class, args);
    }

}
