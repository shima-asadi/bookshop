package ir.javapro.seesion3.exception;

public class RuleException extends RuntimeException {

    public RuleException(String message) {
        super(message);
    }
}
