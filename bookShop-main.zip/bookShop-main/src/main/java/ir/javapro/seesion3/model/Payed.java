package ir.javapro.seesion3.model;

public enum Payed {

    PAYED,
    UNPAYED
}
