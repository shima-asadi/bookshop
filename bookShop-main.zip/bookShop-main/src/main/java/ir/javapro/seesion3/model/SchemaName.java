package ir.javapro.seesion3.model;

public interface SchemaName {

    String SchemaName = "shop";
}
